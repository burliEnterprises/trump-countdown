package com.afollestad.materialdialogs.internal;

import com.afollestad.materialdialogs.MaterialDialog;

/**
 * @author Aidan Follestad (afollestad)
 */
public interface MDAdapter {

    void setDialog(MaterialDialog dialog);
}
